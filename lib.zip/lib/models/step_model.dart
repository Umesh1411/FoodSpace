// lib/models/step_model.dart
import 'package:flutter/material.dart';

class StepModel {
  final String title;
  final IconData icon;
  final Alignment alignment;

  StepModel({
    required this.title,
    required this.icon,
    required this.alignment,
  });
}

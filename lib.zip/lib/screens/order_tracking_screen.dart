import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../widgets/roadmap_painter.dart';
import '../widgets/plane_animator.dart';
import '../widgets/path_position_data.dart';

class OrderTrackingScreen extends StatefulWidget {
  const OrderTrackingScreen({super.key});

  @override
  State<OrderTrackingScreen> createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends State<OrderTrackingScreen> {
  int currentStep = 0;

  final List<Map<String, dynamic>> steps = [
    {'title': 'Select Timer', 'icon': FontAwesomeIcons.clock},
    {'title': 'Waiting for Acceptance', 'icon': FontAwesomeIcons.hourglassHalf},
    {'title': 'Make Payment', 'icon': FontAwesomeIcons.wallet},
    {'title': 'Token Generation', 'icon': FontAwesomeIcons.ticket},
    {'title': 'Waiting to be Taken', 'icon': FontAwesomeIcons.utensils},
    {'title': 'Order in Process', 'icon': FontAwesomeIcons.fireFlameCurved},
    {'title': 'Order Ready', 'icon': FontAwesomeIcons.bell},
    {'title': 'Order Delivered', 'icon': FontAwesomeIcons.circleCheck},
  ];

  void goToNextStep() {
    if (currentStep < steps.length - 1) {
      setState(() {
        currentStep++;
      });
    }
  }
// send request
  Future<void> _handleSelectTimer(int index) async {
    final localContext = context; // ✅ Save context
    final picked = await showTimePicker(
      context: localContext,
      initialTime: TimeOfDay.now(),
    );

    if (picked != null) {
      if (!mounted) return;

      ScaffoldMessenger.of(localContext).showSnackBar(
        SnackBar(content: Text('Timer set for ${picked.format(localContext)}')),
      );

      // ✅ Trigger request to Admin
      await _sendTimerToAdmin(picked);

      setState(() {
        currentStep = index;
      });
    }
  }

  Future<void> _sendTimerToAdmin(TimeOfDay pickedTime) async {
    // TODO: Implement API request here later
    print('Send timer ${pickedTime.format(context)} to Admin');
  }




  @override
  Widget build(BuildContext context) {
    final positions = PathPositionData.stepPoints;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Order Progress'),
        backgroundColor: Colors.orange,
        foregroundColor: Colors.white,
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: InteractiveViewer(
            maxScale: 2,
            minScale: 1,
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: 1200, // ✅ ensure enough vertical space
              child: Stack(
                children: [
                  // Roadmap lines
                  CustomPaint(
                    size: const Size(400, 1100),
                    painter: RoadmapPainter(currentStep: currentStep),
                  ),

                  // Step icons
                  ...List.generate(steps.length, (index) {
                    final isActive = index <= currentStep;
                    final offset = positions[index];
                    return Positioned(
                      left: offset.dx - 24,
                      top: offset.dy - 24,
                      child: GestureDetector(


                        onTap: () {
                          if (index == 0) {
                            _handleSelectTimer(index);
                          } else {
                            setState(() {
                              currentStep = index;
                            });
                          }
                        },




                        child: Column(
                          children: [
                            Container(
                              width: 48,
                              height: 48,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: index == currentStep
                                    ? Colors.orange
                                    : index < currentStep
                                    ? Colors.green
                                    : Colors.grey.shade300,
                                border: Border.all(
                                  color: index < currentStep
                                      ? Colors.green
                                      : index == currentStep
                                      ? Colors.orange.shade700
                                      : Colors.grey,
                                  width: 2,
                                ),
                              ),
                              child: Center(
                                child: Icon(
                                  steps[index]['icon'],
                                  color: Colors.white,
                                  size: 20,
                                ),
                              ),
                            ),

                            const SizedBox(height: 4),
                            SizedBox(
                              width: 80,
                              child: Text(
                                steps[index]['title'],
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  color: isActive ? Colors.black : Colors.grey,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    );
                  }),

                  // Plane
                  PlaneAnimationWidget(currentStep: currentStep),
                ],
              ),
            ),
          ),
        ),
      ),



      // Animated Plane

      floatingActionButton: FloatingActionButton.extended(
        onPressed: goToNextStep,
        backgroundColor: Colors.orange,
        icon: const Icon(Icons.flight_takeoff),
        label: const Text('Next Step'),
      ),
    );


  }
}

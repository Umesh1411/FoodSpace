import 'dart:ui';

class PathPositionData {
  // List of points representing each step on the curved roadmap
  static final List<Offset> stepPoints = [
    const Offset(60, 100),   // Step 1
    const Offset(250, 180),  // Step 2
    const Offset(120, 300),  // Step 3
    const Offset(280, 400),  // Step 4
    const Offset(90, 500),   // Step 5
    const Offset(240, 600),  // Step 6
    const Offset(140, 700),  // Step 7
    const Offset(260, 800),  // Step 8
  ];
}

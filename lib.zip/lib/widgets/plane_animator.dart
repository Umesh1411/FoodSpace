import 'dart:math';
import 'package:flutter/material.dart';
import 'path_position_data.dart';

class PlaneAnimationWidget extends StatelessWidget {
  final int currentStep;

  const PlaneAnimationWidget({super.key, required this.currentStep});

  @override
  Widget build(BuildContext context) {
    final positions = PathPositionData.stepPoints;

    if (currentStep >= positions.length) return const SizedBox();

    final current = positions[currentStep];
    final previous = currentStep > 0 ? positions[currentStep - 1] : current;

    // Calculate direction vector
    final dx = current.dx - previous.dx;
    final dy = current.dy - previous.dy;

    // Calculate angle in radians
    final angle = atan2(dy, dx);

    return AnimatedPositioned(
      duration: const Duration(milliseconds: 1000),
      left: current.dx - 20,
      top: current.dy - 20,
      child: Transform.rotate(
        angle: angle,
        child: const Icon(
          Icons.flight,
          color: Colors.orange,
          size: 40,
        ),
      ),
    );
  }
}

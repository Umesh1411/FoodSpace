import 'package:flutter/material.dart';
import 'path_position_data.dart';

class RoadmapPainter extends CustomPainter {
  final int currentStep;

  RoadmapPainter({required this.currentStep});

  @override
  void paint(Canvas canvas, Size size) {
    final greyPaint = Paint()
      ..color = Colors.grey.withAlpha((0.3 * 255).toInt())
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke;

    final orangeLinePaint = Paint()
      ..color = Colors.orange
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke;

    final points = PathPositionData.stepPoints;

    // Draw dotted base roadmap
    for (int i = 0; i < points.length - 1; i++) {
      final p1 = points[i];
      final p2 = points[i + 1];

      const double gap = 10;
      final totalDistance = (p2 - p1).distance;
      final dx = (p2.dx - p1.dx) / totalDistance * gap;
      final dy = (p2.dy - p1.dy) / totalDistance * gap;

      for (double j = 0; j < totalDistance; j += gap * 2) {
        final x = p1.dx + dx * j;
        final y = p1.dy + dy * j;
        canvas.drawCircle(Offset(x, y), 2.5, greyPaint);
      }
    }

    // Draw solid orange path up to current step
    if (currentStep > 0) {
      final activePath = Path();
      activePath.moveTo(points[0].dx, points[0].dy);
      for (int i = 1; i <= currentStep && i < points.length; i++) {
        activePath.lineTo(points[i].dx, points[i].dy);
      }
      canvas.drawPath(activePath, orangeLinePaint);
    }
  }


  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

import 'package:flutter/material.dart';

class StepButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  final bool isCompleted;
  final VoidCallback onTap;

  const StepButton({
    super.key,
    required this.icon,
    required this.label,
    required this.isActive,
    required this.isCompleted,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final activeColor = Colors.orange;
    final inactiveColor = Colors.grey.shade300;

    final Color bgColor = isActive
        ? const Color.fromARGB(38, 255, 165, 0) // Orange with ~15% opacity
        : const Color.fromARGB(13, 128, 128, 128); // Grey with ~5% opacity

    return Column(
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: bgColor,
              border: Border.all(
                color: isActive ? activeColor : inactiveColor,
                width: 2,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Icon(
                  icon,
                  color: isCompleted
                      ? Colors.green
                      : isActive
                      ? activeColor
                      : Colors.grey,
                  size: 30,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight:
                      isActive ? FontWeight.bold : FontWeight.normal,
                      color: isActive ? Colors.black : Colors.grey[700],
                    ),
                  ),
                ),
                if (isCompleted)
                  const Icon(Icons.check_circle, color: Colors.green)
              ],
            ),
          ),
        ),
      ],
    );
  }
}
